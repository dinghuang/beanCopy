- [ ] Is this an issue (and hence not a question)? 

If this is a question how to use MapStruct there are several resources available.
- Our reference- and API [documentation](http://mapstruct.org/documentation/reference-guide/).
- Our [examples](https://github.com/mapstruct/mapstruct-examples) repository (contributions always welcome)
- Our [FAQ](http://mapstruct.org/faq/)
- [StackOverflow](https://stackoverflow.com), tag MapStruct 
- [Gitter](https://gitter.im/mapstruct/mapstruct-users) (you usually get fast feedback)
- Our [google group](https://groups.google.com/forum/#!forum/mapstruct-users)