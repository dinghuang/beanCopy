/*
 * Copyright MapStruct Authors.
 *
 * Licensed under the Apache License version 2.0, available at http://www.apache.org/licenses/LICENSE-2.0
 */
/**
 * <p>
 * This package contains the generated gem types for accessing the MapStruct annotations in a comfortable way.
 * </p>
 */
package org.mapstruct.ap.internal.gem;
