/*
 * Copyright MapStruct Authors.
 *
 * Licensed under the Apache License version 2.0, available at http://www.apache.org/licenses/LICENSE-2.0
 */
module test.mapstruct {
    requires org.mapstruct;
    exports org.mapstruct.itest.modules;
}
